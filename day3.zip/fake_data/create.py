from faker import Faker
import shortuuid
import pandas as pd

def create_fake_dataframe(n):
    data = [create_fake_user() for _ in range(n)]
    
    df = pd.DataFrame(data)
    
    return df

def create_fake_user():
    
    key_list = ['name', 'job', 'residence', 'blood_group', 'sex', 'birthdate']
    fake = Faker("ko_KR")
    user_data = dict()

    for key in key_list:
        user_data[key] = fake.profile()[key]
        
        if key == 'birthdate':
            user_data[key] = str(fake.profile()[key].year) + str(fake.profile()[key].month).zfill(2) + str(fake.profile()[key].day).zfill(2)

    user_data['uuid'] = shortuuid.uuid()
    
    return user_data