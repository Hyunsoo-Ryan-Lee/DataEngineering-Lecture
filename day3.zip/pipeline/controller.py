from db.connector import DBconnector
from db.postgresql_query import queries
from pipeline.extract import extractor
from pipeline.data_transform import transformer
from pipeline.load import loader
from pipeline.remove import remover
from settings import DB_SETTINGS, TEMP_PATH


def main(batch_date):
    
    for table_name in queries:
        db_connector = DBconnector(**DB_SETTINGS['POSTGRES'])
        pandas_df = extractor(db_connector, table_name, batch_date)
        
        processed_df = transformer(batch_date, pandas_df, table_name)

        db_connector = DBconnector(**DB_SETTINGS['MYSQL'])
        loader(db_connector, processed_df, "mysql_fake")
            
    # remover(TEMP_PATH)