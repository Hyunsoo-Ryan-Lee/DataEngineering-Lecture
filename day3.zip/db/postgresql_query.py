queries = {
    "fake": "SELECT * FROM fake"
}