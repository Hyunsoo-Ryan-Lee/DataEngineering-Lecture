queries = {
    "member": "SELECT * FROM member",
    "regdate_his": "SELECT * FROM regdate_his WHERE regdate = '{batch_date}'",
    # "item_his": "SELECT * FROM item_his",
}