queries = {
    # "테이블 이름" : "테이블에 대한 쿼리"
    "fake" : "SELECT * FROM fake",
}